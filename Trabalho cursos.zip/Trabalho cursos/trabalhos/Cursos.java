package org.trabalhos;

public class Cursos {
		private int idcursos;	
		private String nomecurso;
		private String duracao;
		private String instituicao;
		private String modalidade;
		
		
public int getIdcursos() {
	return idcursos;
}
public void setIdcursos(int idcursos) {
	this.idcursos = idcursos;
}
public String getNomecurso() {
	return nomecurso;
}
public void setNomecurso(String nomecurso) {
	this.nomecurso = nomecurso;
}
public String getDuracao() {
	return duracao;
}
public void setDuracao(String duracao) {
	this.duracao = duracao;
}
public String getInstituicao() {
	return instituicao;
}
public void setInstituicao(String instituicao) {
	this.instituicao = instituicao;
}
public String getModalidade() {
	return modalidade;
}
public void setModalidade(String modalidade) {
	this.modalidade = modalidade;
}

public String toString() {
	return "";
}

}